export abstract class Base {
  id: string;
}
