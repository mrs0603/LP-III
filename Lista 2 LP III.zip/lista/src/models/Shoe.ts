import { Base } from "./Base";

export class Shoe extends Base {
  number: number;
  brand: string;
  model: string;
}
