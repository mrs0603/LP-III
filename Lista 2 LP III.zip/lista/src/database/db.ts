import { Shoe } from "../models/Shoe";

export const db = {
  shoes: [] as Shoe[],
};
